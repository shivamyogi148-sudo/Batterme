package com.betterme.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
